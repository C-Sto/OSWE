<?php 

	require(AT_INCLUDE_PATH.'header.inc.php'); 

	require(AT_INCLUDE_PATH.'footer.inc.php'); 
?>