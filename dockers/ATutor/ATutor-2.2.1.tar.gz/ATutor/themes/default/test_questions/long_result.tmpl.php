<p><?php echo AT_print($this->row['question'], 'tests_questions.quotesNotConverted'); ?></p>

<p style="font-family: curior new; font-size: medium"><?php echo AT_print($this->answer, 'tests_answers.answer'); ?></p>
