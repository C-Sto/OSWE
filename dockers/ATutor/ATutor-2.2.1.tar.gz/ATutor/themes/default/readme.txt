
Theme:		1.6 Default Theme
Date:		December 2007


Installing:	 See section "Installing a New Theme" in the themes_readme.txt file located in the themes/ top directory.

Licence:	Falls under the GPL agreement.  See http://www.gnu.org/copyleft/gpl.html.
	